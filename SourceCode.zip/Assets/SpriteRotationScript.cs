﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
public class SpriteRotationScript : MonoBehaviour
{


    XMLParsingScripts xmlParsingScripts;




    public GameObject temp_GameObject; //#.SpriteRender생성할 Object
    //실험

    GameObject sprite_RealGroup_Object;

    ButtonManager buttonManager;
    
    private float rotationX = 0f;
    private float rotationY = 0f;
    public float mouseSpeed = 100f;
    private float touchSpeed = 200f;



    private float position_X = 0f;
    private float position_Y = 0f;
    private float position_Z = 0f;


    private float transform_localScale_X = 0f;
    private float transform_localScale_Y = 0f;




    public float minY = -85f;
    public float maxY = 85f;


    float distance = 10;


    private Ray ray;
    private RaycastHit hit;
    public LayerMask layerMask; //#.pooImage에 쓸것
    Button automaticButton;
    int mask = 1 << 9;

    GameObject player;

    private void Awake()
    {
        buttonManager = GameObject.FindGameObjectWithTag("ButtonManager").GetComponent<ButtonManager>();
        sprite_RealGroup_Object = GameObject.FindGameObjectWithTag("SpriteRealGroupObject");
        automaticButton = GameObject.FindGameObjectWithTag("AutoMaticButtonTag").GetComponent<Button>();
        player = GameObject.FindGameObjectWithTag("Player");
        xmlParsingScripts = GameObject.FindGameObjectWithTag("XMLParsing").GetComponent<XMLParsingScripts>();
    }

#if UNITY_EDITOR
    void OnMouseDrag()
    {
        if (EventSystem.current.IsPointerOverGameObject() == false)
        {
            if (buttonManager.GetXPositionVariable())
            {


                if (buttonManager.GetPlusVariable())
                {
                    float picture_transform_xPosition = transform.position.x;
                    float picture_transform_yPosition = transform.position.y;
                    float picture_transform_zPosition = transform.position.z;
                    picture_transform_xPosition += 0.5f;

                    Vector3 picture_transform = new Vector3(picture_transform_xPosition, picture_transform_yPosition, picture_transform_zPosition);

                    transform.position = picture_transform;
                }
                else if (buttonManager.GetMinusVariable())
                {
                    float picture_transform_xPosition = transform.position.x;
                    float picture_transform_yPosition = transform.position.y;
                    float picture_transform_zPosition = transform.position.z;
                    picture_transform_xPosition -= 0.5f;

                    Vector3 picture_transform = new Vector3(picture_transform_xPosition, picture_transform_yPosition, picture_transform_zPosition);

                    transform.position = picture_transform;
                }

            }
            else if (buttonManager.GetYPositionVariable())
            {
                if (buttonManager.GetPlusVariable())
                {
                    float picture_transform_xPosition = transform.position.x;
                    float picture_transform_yPosition = transform.position.y;
                    float picture_transform_zPosition = transform.position.z;
                    picture_transform_yPosition += 0.5f;

                    Vector3 picture_transform = new Vector3(picture_transform_xPosition, picture_transform_yPosition, picture_transform_zPosition);

                    transform.position = picture_transform;
                }
                else if (buttonManager.GetMinusVariable())
                {
                    float picture_transform_xPosition = transform.position.x;
                    float picture_transform_yPosition = transform.position.y;
                    float picture_transform_zPosition = transform.position.z;
                    picture_transform_yPosition -= 0.5f;

                    Vector3 picture_transform = new Vector3(picture_transform_xPosition, picture_transform_yPosition, picture_transform_zPosition);

                    transform.position = picture_transform;
                }
            }
            else if (buttonManager.GetZPositionVariable())
            {
                if (buttonManager.GetPlusVariable())
                {
                    float picture_transform_xPosition = transform.position.x;
                    float picture_transform_yPosition = transform.position.y;
                    float picture_transform_zPosition = transform.position.z;
                    picture_transform_zPosition += 0.5f;

                    Vector3 picture_transform = new Vector3(picture_transform_xPosition, picture_transform_yPosition, picture_transform_zPosition);

                    transform.position = picture_transform;
                }
                else if (buttonManager.GetMinusVariable())
                {
                    float picture_transform_xPosition = transform.position.x;
                    float picture_transform_yPosition = transform.position.y;
                    float picture_transform_zPosition = transform.position.z;
                    picture_transform_zPosition -= 0.5f;

                    Vector3 picture_transform = new Vector3(picture_transform_xPosition, picture_transform_yPosition, picture_transform_zPosition);

                    transform.position = picture_transform;
                }
            }


        }



    }
#elif UNITY_ANDROID || UNITY_IOS
  
       



    
#endif
    void Update()
    {
#if UNITY_EDITOR
        if (EventSystem.current.IsPointerOverGameObject() == false)
        {
            if (buttonManager.GetEditVariable()) //#.EditVariable이 True면
            {
                if (Input.GetMouseButton(0))
                {

                    ray = Camera.main.ScreenPointToRay(Input.mousePosition);

                    if (Physics.Raycast(ray, out hit, Mathf.Infinity, mask))
                    {
                        Debug.Log("RayCast");
                        if (hit.transform.gameObject.tag == "GallaryImageTag")
                        {
                            Debug.Log("GallaryImageTagClick");
                        }
                    }
                    else
                    {
                        rotationX -= Input.GetAxis("Mouse X") * mouseSpeed * Time.deltaTime;
                        rotationY += Input.GetAxis("Mouse Y") * 1.5f * mouseSpeed * Time.deltaTime;

                    }

                    rotationY = ClampAngle(rotationY, minY, maxY);
                    Quaternion rotation = Quaternion.Euler(rotationY, rotationX, 0f);
                    transform.rotation = rotation;

                }

            }
            else if (buttonManager.GetScaleButtonVariable())
            {
                if (Input.GetMouseButton(0))
                {

                    ray = Camera.main.ScreenPointToRay(Input.mousePosition);

                    if (Physics.Raycast(ray, out hit, Mathf.Infinity, mask))
                    {
                        Debug.Log("RayCast");
                        if (hit.transform.gameObject.tag == "GallaryImageTag")
                        {
                            Debug.Log("GallaryImageTagClick");
                        }
                    }
                    else
                    {

                        transform_localScale_X += Input.GetAxis("Mouse X");// * mouseSpeed * Time.deltaTime;
                        transform_localScale_Y += Input.GetAxis("Mouse Y");// * 1.5f * mouseSpeed * Time.deltaTime;

                    }



                    // Quaternion rotation = Quaternion.Euler(rotationY, rotationX, 0f);
                    transform.localScale = new Vector2(transform_localScale_X, transform_localScale_Y);

                }
            }




            MouseClickEvent();

        }


#elif UNITY_ANDROID || UNITY_IOS
         if (Input.touchCount > 0)

        {

            Vector2 pos = Input.GetTouch(0).position;    // 터치한 위치

            Vector3 theTouch = new Vector3(pos.x, pos.y, 0.0f);    // 변환 안하고 바로 Vector3로 받아도 되겠지.



            Ray ray = Camera.main.ScreenPointToRay(theTouch);    // 터치한 좌표 레이로 바꾸엉

            RaycastHit hit;    // 정보 저장할 구조체 만들고

            if (Physics.Raycast(ray, out hit, Mathf.Infinity))    // 레이저를 끝까지 쏴블자. 충돌 한넘이 있으면 return true다.

            {

                if (Input.GetTouch(0).phase == TouchPhase.Began)    // 딱 처음 터치 할때 발생한다

                {

                    // 할거 하고

                }

                else if (Input.GetTouch(0).phase == TouchPhase.Moved)    // 터치하고 움직이믄 발생한다.

                {
                    if (EventSystem.current.IsPointerOverGameObject() == false)
                    {
                        if (buttonManager.GetEditVariable()) //#.EditVariable이 True면
                        {




                            if (Physics.Raycast(ray, out hit, Mathf.Infinity, mask))
                            {
                                Debug.Log("RayCast");
                                if (hit.transform.gameObject.tag == "GallaryImageTag")
                                {
                                    Debug.Log("GallaryImageTagClick");
                                }
                            }
                            else
                            {
                                rotationX -= Input.touches[0].deltaPosition.x * touchSpeed * Time.deltaTime;
                                rotationY += Input.touches[0].deltaPosition.y * touchSpeed * Time.deltaTime;

                            }

                            rotationY = ClampAngle(rotationY, minY, maxY);
                            Quaternion rotation = Quaternion.Euler(rotationY, rotationX, 0f);
                            transform.rotation = rotation;



                        }
                        else if (buttonManager.GetScaleButtonVariable())
                        {
                            if (Input.GetMouseButton(0))
                            {


                                if (Physics.Raycast(ray, out hit, Mathf.Infinity, mask))
                                {
                                    Debug.Log("RayCast");
                                    if (hit.transform.gameObject.tag == "GallaryImageTag")
                                    {
                                        Debug.Log("GallaryImageTagClick");
                                    }
                                }
                                else
                                {

                                    transform_localScale_X += Input.touches[0].deltaPosition.x * touchSpeed;// * mouseSpeed * Time.deltaTime;
                                    transform_localScale_Y += Input.touches[0].deltaPosition.y * touchSpeed;// * 1.5f * mouseSpeed * Time.deltaTime;

                                }

                                transform.localScale = new Vector2(transform_localScale_X, transform_localScale_Y);

                            }
                        }




                        MouseClickEvent();

                    }

                }

                else if (Input.GetTouch(0).phase == TouchPhase.Ended)    // 터치 따악 떼면 발생한다.

                {

                    // 할거 해라.

                }

            }

        }

          if (Input.touchCount > 0)

        {

            Vector2 pos = Input.GetTouch(0).position;    // 터치한 위치

            Vector3 theTouch = new Vector3(pos.x, pos.y, 0.0f);    // 변환 안하고 바로 Vector3로 받아도 되겠지.



            Ray ray = Camera.main.ScreenPointToRay(theTouch);    // 터치한 좌표 레이로 바꾸엉

            RaycastHit hit;    // 정보 저장할 구조체 만들고

            if (Physics.Raycast(ray, out hit, Mathf.Infinity))    // 레이저를 끝까지 쏴블자. 충돌 한넘이 있으면 return true다.

            {

                if (Input.GetTouch(0).phase == TouchPhase.Began)    // 딱 처음 터치 할때 발생한다

                {

                    

                }

                else if (Input.GetTouch(0).phase == TouchPhase.Moved)    // 터치하고 움직이믄 발생한다.

                {
                 if (EventSystem.current.IsPointerOverGameObject() == false)
        {
            if (buttonManager.GetXPositionVariable())
            {


                if (buttonManager.GetPlusVariable())
                {
                    float picture_transform_xPosition = transform.position.x;
                    float picture_transform_yPosition = transform.position.y;
                    float picture_transform_zPosition = transform.position.z;
                    picture_transform_xPosition += 0.5f;

                    Vector3 picture_transform = new Vector3(picture_transform_xPosition, picture_transform_yPosition, picture_transform_zPosition);

                    transform.position = picture_transform;
                }
                else if (buttonManager.GetMinusVariable())
                {
                    float picture_transform_xPosition = transform.position.x;
                    float picture_transform_yPosition = transform.position.y;
                    float picture_transform_zPosition = transform.position.z;
                    picture_transform_xPosition -= 0.5f;

                    Vector3 picture_transform = new Vector3(picture_transform_xPosition, picture_transform_yPosition, picture_transform_zPosition);

                    transform.position = picture_transform;
                }

            }
            else if (buttonManager.GetYPositionVariable())
            {
                if (buttonManager.GetPlusVariable())
                {
                    float picture_transform_xPosition = transform.position.x;
                    float picture_transform_yPosition = transform.position.y;
                    float picture_transform_zPosition = transform.position.z;
                    picture_transform_yPosition += 0.5f;

                    Vector3 picture_transform = new Vector3(picture_transform_xPosition, picture_transform_yPosition, picture_transform_zPosition);

                    transform.position = picture_transform;
                }
                else if (buttonManager.GetMinusVariable())
                {
                    float picture_transform_xPosition = transform.position.x;
                    float picture_transform_yPosition = transform.position.y;
                    float picture_transform_zPosition = transform.position.z;
                    picture_transform_yPosition -= 0.5f;

                    Vector3 picture_transform = new Vector3(picture_transform_xPosition, picture_transform_yPosition, picture_transform_zPosition);

                    transform.position = picture_transform;
                }
            }
            else if (buttonManager.GetZPositionVariable())
            {
                if (buttonManager.GetPlusVariable())
                {
                    float picture_transform_xPosition = transform.position.x;
                    float picture_transform_yPosition = transform.position.y;
                    float picture_transform_zPosition = transform.position.z;
                    picture_transform_zPosition += 0.5f;

                    Vector3 picture_transform = new Vector3(picture_transform_xPosition, picture_transform_yPosition, picture_transform_zPosition);

                    transform.position = picture_transform;
                }
                else if (buttonManager.GetMinusVariable())
                {
                    float picture_transform_xPosition = transform.position.x;
                    float picture_transform_yPosition = transform.position.y;
                    float picture_transform_zPosition = transform.position.z;
                    picture_transform_zPosition -= 0.5f;

                    Vector3 picture_transform = new Vector3(picture_transform_xPosition, picture_transform_yPosition, picture_transform_zPosition);

                    transform.position = picture_transform;
                }
            }


        }


                

                }

                else if (Input.GetTouch(0).phase == TouchPhase.Ended)    // 터치 따악 떼면 발생한다.

                {

                    // 할거 해라.

                }

            }

        }
#endif

    }




    private float ClampAngle(float angle, float min, float max)
    {
        if (angle < -360f)
        {
            angle += 360f;
        }

        if (angle > 360f)
        {
            angle -= 360f;
        }

        return Mathf.Clamp(angle, min, max);
    }


    private void MouseClickEvent()
    {
        if (buttonManager.automatic_Button_Variable)
        {
            AutoMaticResult();
        }



    }

    public void AutoMaticResult()
    {
#if UNITY_EDITOR
        Ray ray_temp;
        RaycastHit hitInfo_temp;

        ray_temp = Camera.main.ScreenPointToRay(Input.mousePosition);
        
        if (Input.GetMouseButtonDown(0))
        {

            if (Physics.Raycast(ray_temp, out hitInfo_temp))
            {


                temp_GameObject = Instantiate(hitInfo_temp.transform.gameObject, hitInfo_temp.transform.position, hitInfo_temp.transform.rotation);
                temp_GameObject.transform.parent= hitInfo_temp.transform;


                temp_GameObject.transform.localPosition= new Vector3(0, 0, 0);

                temp_GameObject.transform.localEulerAngles = new Vector3(0, 0, 0);
                

                if (hitInfo_temp.transform.rotation.z  >0)
                {
                    Vector3 vector_temp = new Vector3(0, 0, -90);
                    temp_GameObject.transform.localEulerAngles = vector_temp;
                    //Quaternion.Euler(0, 0, -90);
                }
                else if (hitInfo_temp.transform.rotation.z < 0)
                {
                    Vector3 vector_temp = new Vector3(0, 0, 90);
                    temp_GameObject.transform.localEulerAngles = vector_temp;
                }
                else if(hitInfo_temp.transform.rotation.x >0 || hitInfo_temp.transform.rotation.x < 0 || hitInfo_temp.transform.rotation.y >0 || hitInfo_temp.transform.rotation.y < 0) 
                {
                    Vector3 vector_temp = new Vector3(0, 0, 90);
                    temp_GameObject.transform.localEulerAngles = vector_temp;

                }
                temp_GameObject.transform.localScale = new Vector3(hitInfo_temp.transform.localScale.x, hitInfo_temp.transform.localScale.y, 1);
                MeshRenderer temp_MeshRenderer = temp_GameObject.GetComponent<MeshRenderer>();
                Destroy(temp_MeshRenderer);
                MeshFilter temp_MeshFilter = temp_GameObject.GetComponent<MeshFilter>();

                Destroy(temp_MeshFilter);
                StartCoroutine(SpriteRenderLoadCoroutine(temp_GameObject,hitInfo_temp.transform.gameObject));
            }
        }



#elif UNITY_ANDROID || UNITY_IOS
         if (Input.touchCount > 0)

        {

            Vector2 pos = Input.GetTouch(0).position;    // 터치한 위치

            Vector3 theTouch = new Vector3(pos.x, pos.y, 0.0f);    // 변환 안하고 바로 Vector3로 받아도 되겠지.



            Ray ray = Camera.main.ScreenPointToRay(theTouch);    // 터치한 좌표 레이로 바꾸엉

            RaycastHit hitInfo_temp;    // 정보 저장할 구조체 만들고

            if (Physics.Raycast(ray, out hitInfo_temp, Mathf.Infinity))    // 레이저를 끝까지 쏴블자. 충돌 한넘이 있으면 return true다.

            {

                if (Input.GetTouch(0).phase == TouchPhase.Began)    // 딱 처음 터치 할때 발생한다

                {

                    // 할거 하고

                }

                else if (Input.GetTouch(0).phase == TouchPhase.Moved)    // 터치하고 움직이믄 발생한다.

                {
                    temp_GameObject = Instantiate(hitInfo_temp.transform.gameObject, hitInfo_temp.transform.position, hitInfo_temp.transform.rotation);
                    temp_GameObject.transform.parent = hitInfo_temp.transform;


                    temp_GameObject.transform.localPosition = new Vector3(0, 0, 0);

                    temp_GameObject.transform.localEulerAngles = new Vector3(0, 0, 0);


                    if (hitInfo_temp.transform.rotation.z > 0)
                    {
                        Vector3 vector_temp = new Vector3(0, 0, -90);
                        temp_GameObject.transform.localEulerAngles = vector_temp;
                        //Quaternion.Euler(0, 0, -90);
                    }
                    else if (hitInfo_temp.transform.rotation.z < 0)
                    {
                        Vector3 vector_temp = new Vector3(0, 0, 90);
                        temp_GameObject.transform.localEulerAngles = vector_temp;
                    }
                    else if (hitInfo_temp.transform.rotation.x > 0 || hitInfo_temp.transform.rotation.x < 0 || hitInfo_temp.transform.rotation.y > 0 || hitInfo_temp.transform.rotation.y < 0)
                    {
                        Vector3 vector_temp = new Vector3(0, 0, 90);
                        temp_GameObject.transform.localEulerAngles = vector_temp;

                    }
                    temp_GameObject.transform.localScale = new Vector3(hitInfo_temp.transform.localScale.x, hitInfo_temp.transform.localScale.y, 1);
                    MeshRenderer temp_MeshRenderer = temp_GameObject.GetComponent<MeshRenderer>();
                    Destroy(temp_MeshRenderer);
                    MeshFilter temp_MeshFilter = temp_GameObject.GetComponent<MeshFilter>();

                    Destroy(temp_MeshFilter);
                    StartCoroutine(SpriteRenderLoadCoroutine(temp_GameObject, hitInfo_temp.transform.gameObject));

                }

                else if (Input.GetTouch(0).phase == TouchPhase.Ended)    // 터치 따악 떼면 발생한다.

                {

                    // 할거 해라.

                }

            }

        }
#endif
    }
    private IEnumerator SpriteRenderLoadCoroutine(GameObject temp_GameObject,GameObject hitInfo_GameObject)   //#. hitinfo가 맞은거니까 이게 박
    {
        yield return new WaitForSeconds(6f);

        SpriteRenderer spriteRenderer_temp = temp_GameObject.AddComponent<SpriteRenderer>();
        spriteRenderer_temp.drawMode = SpriteDrawMode.Sliced;
        spriteRenderer_temp.sprite = buttonManager.sr.sprite;
        float x_boxColider_size = hitInfo_GameObject.transform.gameObject.GetComponent<BoxCollider>().size.x;
        float y_boxColider_size = hitInfo_GameObject.transform.gameObject.GetComponent<BoxCollider>().size.y;
        hitInfo_GameObject.transform.gameObject.GetComponent<BoxCollider>().size = new Vector2(y_boxColider_size, x_boxColider_size);
        spriteRenderer_temp.size = hitInfo_GameObject.transform.gameObject.GetComponent<BoxCollider>().size;
        buttonManager.automatic_Button_Variable = false;
       automaticButton.interactable = true;
        buttonManager.sr.gameObject.SetActive(false);
        xmlParsingScripts.mouseColliderCapsule.SetActive(false);
    }
}
