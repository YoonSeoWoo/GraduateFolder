﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class PositionAndUrlClass
{

    public List<Information> informaiton = new List<Information>();

    
}
