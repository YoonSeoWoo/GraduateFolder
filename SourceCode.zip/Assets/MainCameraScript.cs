﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
public class MainCameraScript : MonoBehaviour {


    ButtonManager buttonManager;


    bool mode_Bool_Value;
    Camera camera_MainCamera;
    private float rotationX = 0f;
    private float rotationY = 0f;


    private float positionX = 0f;
    private float positionY = 0f;
    private float positionZ = 0f;

    




    public float mouseSpeed = 50f;


    public float rotation_minY = -85f;
    public float rotation_maxY = 85f;




    private Ray ray;
    private RaycastHit hit;
    public LayerMask layerMask; //#.pooImage에 쓸것

    int mask = 1 << 9;
    // Use this for initialization

    private void Awake()
    {
        buttonManager = GameObject.FindGameObjectWithTag("ButtonManager").GetComponent<ButtonManager>();
    }
    void Start () {
        camera_MainCamera = gameObject.GetComponent<Camera>();

    }
	
	// Update is called once per frame
	void Update () {

        //#.카메라를 돌리는것


        if (buttonManager.GetCameraVariable()) //#.camera Variable이 true일때만
        {
            if (EventSystem.current.IsPointerOverGameObject() == false)
            {
                if (Input.GetMouseButton(0))
                {

                    ray = Camera.main.ScreenPointToRay(Input.mousePosition);

                    if (Physics.Raycast(ray, out hit, Mathf.Infinity, mask))
                    {
                        Debug.Log("RayCast");
                        if (hit.transform.gameObject.tag == "GallaryImageTag")
                        {
                            Debug.Log("GallaryImageTagClick");
                        }
                    }
                    else
                    {
                        rotationX += Input.GetAxis("Mouse X") * mouseSpeed * Time.deltaTime;
                        rotationY -= Input.GetAxis("Mouse Y") * 1.5f * mouseSpeed * Time.deltaTime;

                    }

                    rotationY = ClampAngle(rotationY, rotation_minY, rotation_maxY);
                    Quaternion rotation = Quaternion.Euler(rotationY, rotationX, 0f);
                    transform.rotation = rotation;

                } //#.카메라 회전
            }
           
        }
        

      /*  if (Input.GetMouseButtonDown(0))
        {
            ray = Camera.main.ScreenPointToRay(Input.mousePosition);

            if (Physics.Raycast(ray, out hit, Mathf.Infinity, mask))
            {
                Debug.Log("RayCast");
                if (hit.transform.gameObject.tag == "GallaryImageTag")
                {
                    Debug.Log("GallaryImageTagClick");
                }
            }
            else
            {

                positionX += mouseSpeed * Time.deltaTime;
                positionY -= mouseSpeed * Time.deltaTime;

            }

            positionX = ClampAngle(positionX, 0, 180);
         
            transform.position = new Vector3(positionX,transform.position.y,transform.position.z);
        }*/

        if (Input.GetAxis("Mouse ScrollWheel") < 0)
        {
            camera_MainCamera.fieldOfView-=2;
        }
        else if (Input.GetAxis("Mouse ScrollWheel") > 0)
        {
            camera_MainCamera.fieldOfView+=2;
        }

    }

    private float ClampAngle(float angle, float min, float max)
    {
        if (angle < -360f)
        {
            angle += 360f;
        }

        if (angle > 360f)
        {
            angle -= 360f;
        }

        return Mathf.Clamp(angle, min, max);
    }

    private float PositionCalculate_Clamp(float pos_limit,float pos_min,float pos_max)
    {
        if (pos_limit < -180)
        {
            pos_limit += 180;
        }

        if (pos_limit > 180)
        {
            pos_limit -= 180;
        }
        return Mathf.Clamp(pos_limit, pos_min, pos_max);
    }


}
