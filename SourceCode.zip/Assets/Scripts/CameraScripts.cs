﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraScripts : MonoBehaviour {




    private Touch tempTouchs;
    private Vector3 touchedPos;

    private bool touchOn;







    ButtonManager buttonManager;




    private float rotationX = 0f;
    private float rotationY = 0f;
    public float mouseSpeed = 100f;


    public float minY = -85f;
    public float maxY = 85f;




    private Ray ray;
    private RaycastHit hit;
    public LayerMask layerMask; //#.pooImage에 쓸것

    int mask = 1 << 9;

    private void Awake()
    {
        buttonManager = GameObject.FindGameObjectWithTag("ButtonManager").GetComponent<ButtonManager>();
        touchOn = false;
    }



    //#.mouse Pointer로 잡아끌면 그쪽으로 가게 해둿쪄용 ㅎ
    void Update () {


        if (buttonManager.GetCameraVariable())
        {
#if UNITY_EDITOR
            if (Input.GetMouseButton(0))
            {

                ray = Camera.main.ScreenPointToRay(Input.mousePosition);

                if (Physics.Raycast(ray, out hit, Mathf.Infinity, mask))
                {
                    Debug.Log("RayCast");
                    if (hit.transform.gameObject.tag == "GallaryImageTag")
                    {
                        Debug.Log("GallaryImageTagClick");
                    }
                }
                else
                {
                    rotationX -= Input.GetAxis("Mouse X") * mouseSpeed * Time.deltaTime;
                    rotationY += Input.GetAxis("Mouse Y") * 1.5f * mouseSpeed * Time.deltaTime;

                }

            }
            else if (Input.touchCount > 0)

            {

                Vector2 pos = Input.GetTouch(0).position;    // 터치한 위치

                Vector3 theTouch = new Vector3(pos.x, pos.y, 0.0f);    // 변환 안하고 바로 Vector3로 받아도 되겠지.



                Ray ray = Camera.main.ScreenPointToRay(theTouch);    // 터치한 좌표 레이로 바꾸엉

                RaycastHit hit;    // 정보 저장할 구조체 만들고

                if (Physics.Raycast(ray, out hit, Mathf.Infinity))    // 레이저를 끝까지 쏴블자. 충돌 한넘이 있으면 return true다.

                {

                    if (Input.GetTouch(0).phase == TouchPhase.Began)    // 딱 처음 터치 할때 발생한다

                    {

                        // 할거 하고

                    }

                    else if (Input.GetTouch(0).phase == TouchPhase.Moved)    // 터치하고 움직이믄 발생한다.

                    {

                        rotationX -= Input.touches[0].deltaPosition.x * mouseSpeed * Time.deltaTime;
                        rotationY += Input.touches[0].deltaPosition.y * mouseSpeed * Time.deltaTime;
                        // 또 할거 하고

                    }

                    else if (Input.GetTouch(0).phase == TouchPhase.Ended)    // 터치 따악 떼면 발생한다.

                    {

                        // 할거 해라.

                    }

                }

            }



        

            rotationY = ClampAngle(rotationY, minY, maxY);
            Quaternion rotation = Quaternion.Euler(rotationY, rotationX, 0f);
            transform.rotation = rotation;


#elif UNITY_ANDROID || UNITY_IOS




         


#endif








        }
    }
    private float ClampAngle(float angle, float min, float max)
    {
        if (angle < -360f)
        {
            angle += 360f;
        }

        if (angle > 360f)
        {
            angle -= 360f;
        }

        return Mathf.Clamp(angle, min, max);
    }



}
