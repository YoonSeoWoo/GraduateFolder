﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;

public class WebCam : MonoBehaviour
{


    byte[] bytes_one;

    public GameObject scrollBackGround;


    /*[SerializeField] private int original_width;
    [SerializeField] private int original_height;*/

    [SerializeField] private Vector2 original_Vector;



    public string fileName;
    [SerializeField] private string path;
    public string urlPath;
    [SerializeField] private bool isDownload;

    ButtonManager buttonManager;


    int currentCamIndex = 0;

    WebCamTexture tex;

    public GameObject clonePicture_Group;
    public RawImage display;




    public Text startStopText;




    
    private void Awake()
    {

        clonePicture_Group = GameObject.FindGameObjectWithTag("ClonePicture_Group");
        buttonManager = GameObject.FindGameObjectWithTag("ButtonManager").GetComponent<ButtonManager>();
     
        display.gameObject.SetActive(false);
        

    }

    private void Start()
    {
        fileName = "poo" + buttonManager.picture_number + ".png";
    }

    public void SwapCam_Clicked()
    {
#if UNITY_EDITOR
        if (WebCamTexture.devices.Length > 0)
        {
            currentCamIndex += 1;
            currentCamIndex %= WebCamTexture.devices.Length;

            //if tex is not null;
            //stop the web cam
            //start the web cam

            if (tex != null)
            {
                StopWebCam();
                StartStopCam_Clicked();
            }
        }
        
#elif UNITY_ANDROID
        
#endif
    }
    public void StartStopCam_Clicked()
    {
        display.gameObject.SetActive(true);
#if UNITY_EDITOR
        if (tex != null)
        {
            StopWebCam();
            startStopText.text = "Start Camera";
        }
        else
        {
            int width = Screen.width;
            int height = Screen.height;

            original_Vector = display.gameObject.GetComponentInChildren<RectTransform>().sizeDelta;

            //#.display라는 RawImage의 크기를 늘렸다. 최대로
            display.gameObject.GetComponentInChildren<RectTransform>().sizeDelta = new Vector2(width, height);

            WebCamDevice device = WebCamTexture.devices[currentCamIndex];
            tex = new WebCamTexture(device.name);


            display.texture = tex;

            float antiRotate = (360 - tex.videoRotationAngle);

            Quaternion quatRot = new Quaternion();
            quatRot.eulerAngles = new Vector3(0, 0, antiRotate);
            display.transform.rotation = quatRot;

            tex.Play();

          
        }
#endif
    }

    private void StopWebCam()
    {
#if UNITY_EDITOR
        display.texture = null;
        tex.Stop();
        tex = null;

        //#.display 라는 객체의 RectTransform 을 조정해서 원래의 크기로 조정한다.
        display.gameObject.GetComponentInChildren<RectTransform>().sizeDelta = original_Vector;
#endif
    }

    public void PauseWebCam()  //Picture GetIt 함수를 넣어둔것
    {
#if UNITY_EDITOR
        tex.Pause();
        StartCoroutine(DownLoadPNG());
#endif
    }
    public void onWindowFocusChanged(bool hasFocus) { }

    private IEnumerator DownLoadPNG()
    {

#if UNITY_EDITOR

        yield return new WaitForEndOfFrame();

        int width = Screen.width;
        int height = Screen.height;

        scrollBackGround.transform.GetChild(0).GetChild(0).GetChild(buttonManager.picture_number).gameObject.SetActive(true);
       
        Texture2D texture_2D = new Texture2D(width, height, TextureFormat.ARGB32, false);

        texture_2D.ReadPixels(new Rect(0, 0, width, height), 0, 0);
        
        texture_2D.Apply();




      
        
   

        
     


        // byte[] bytes_one = texture_2D.EncodeToPNG(); //#.잠시 확인을 위해 주석

        bytes_one = texture_2D.EncodeToPNG();

        Object.Destroy(texture_2D);

        string persistentPath = Application.dataPath + "/Resources/Picture/";



     


    

        if (!Directory.Exists(persistentPath))
        {
            Directory.CreateDirectory(persistentPath);
        }


        path = persistentPath + fileName;
 
        File.WriteAllBytes(path, bytes_one);

        //display.gameObject.SetActive(false);
        StopWebCam();

        StartCoroutine(LoadImage());

#elif UNITY_ANDROID
                yield return new WaitForEndOfFrame();
#endif

    }

    private IEnumerator LoadImage()
    {
     
#if UNITY_EDITOR
        yield return new WaitForEndOfFrame();

        int width = Screen.width;
        int height = Screen.height;
        Texture2D texture2d_LoadImage = null;
        texture2d_LoadImage= new Texture2D(width, height, TextureFormat.ARGB32, false);



        texture2d_LoadImage.LoadImage(bytes_one);

        
        scrollBackGround.transform.GetChild(0).GetChild(0).GetChild(buttonManager.picture_number).GetComponent<RawImage>().texture = texture2d_LoadImage;






        buttonManager.picture_number++;
#elif UNITY_ANDROID
           yield return new WaitForEndOfFrame();
#endif

    }

}


