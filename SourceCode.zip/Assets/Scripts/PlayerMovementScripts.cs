﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovementScripts : MonoBehaviour {

    // Use this for initialization
    public float speed = 3f;

    private bool camera_On = true;
   private float rotationX = 0f;
   private float rotationY = 0f;

   public  Camera camera1;
    public Camera camera2;

    ButtonManager buttonManager;
    void Awake()
    {
        camera2.gameObject.SetActive(!camera_On);
        buttonManager = GameObject.FindGameObjectWithTag("ButtonManager").GetComponent<ButtonManager>();


    }

    void FixedUpdate()
    {

        //#.Space바 누르면요 예? 진호가요 카메라가 슉! 바뀌도록해놨어용 헷
        if (Input.GetKeyDown("space"))
        {
            
            camera2.gameObject.SetActive(camera_On);
            camera1.gameObject.SetActive(!camera_On);
            camera_On = !camera_On;
        }


        //키보드의 전후 화살표 받음. 위 max : 1f / 아래 max : -1f
        float vertical = Input.GetAxis("Vertical");

        //키보드의 좌우 화살표 받음. 우 max : 1f / 좌 max : -1f
        float horizontal = Input.GetAxis("Horizontal");



        transform.Translate(Vector3.forward * vertical * Time.deltaTime * speed);
        //transform.Translate() : 정해진 방향으로 이동
        //Vector3.forward : Vector3(0f, 0f, 1f)
        //vertical : -1 ~ 1
        //Time.deltaTime : 0.02f
        //speed : 3f

        transform.Rotate(Vector3.up * horizontal, Space.World);
        //transform.Rotate() : 정해진 방향으로 회전
        //Vector3.up : Vector3(0f, 1f, 0f)
        //horizontal : -1 ~ 1
        //Space.World : 축이 global 좌표


        if (Input.touchCount == 3)

        {

            Vector2 pos = Input.GetTouch(0).position;    // 터치한 위치

            Vector3 theTouch = new Vector3(pos.x, pos.y, 0.0f);    // 변환 안하고 바로 Vector3로 받아도 되겠지.



            Ray ray = Camera.main.ScreenPointToRay(theTouch);    // 터치한 좌표 레이로 바꾸엉

            RaycastHit hit;    // 정보 저장할 구조체 만들고

            if (Physics.Raycast(ray, out hit, Mathf.Infinity))    // 레이저를 끝까지 쏴블자. 충돌 한넘이 있으면 return true다.

            {

                if (Input.GetTouch(0).phase == TouchPhase.Began)    // 딱 처음 터치 할때 발생한다

                {

                    // 할거 하고

                }

                else if (Input.GetTouch(0).phase == TouchPhase.Moved)    // 터치하고 움직이믄 발생한다.

                {
                    float touch_vertical = Input.touches[0].deltaPosition.x;

                    //키보드의 좌우 화살표 받음. 우 max : 1f / 좌 max : -1f

                    float touch_horizontal = Input.touches[0].deltaPosition.y;


                    transform.Translate(Vector3.forward * touch_vertical * Time.deltaTime * speed);
                    //transform.Translate() : 정해진 방향으로 이동
                    //Vector3.forward : Vector3(0f, 0f, 1f)
                    //vertical : -1 ~ 1
                    //Time.deltaTime : 0.02f
                    //speed : 3f

                    transform.Rotate(Vector3.up * touch_horizontal, Space.World);
                    // 또 할거 하고

                }

                else if (Input.GetTouch(0).phase == TouchPhase.Ended)    // 터치 따악 떼면 발생한다.

                {

                    // 할거 해라.

                }

            }

        }


    }


    private void OnTriggerEnter(Collider other)
    {
        if (other.name == "Wall")
        {
            buttonManager.SaveToWallButton_Enable_And_Active_True();

        }
    }

}
