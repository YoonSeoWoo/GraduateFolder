﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.IO;


public class DownloadDB : MonoBehaviour {

   
    public string fileName; //= "poo"+.png";
    [SerializeField] private string path;
    public string urlPath;
    [SerializeField] private bool isDownload;

    private void Awake()
    {
    
    }
    private void Start()
    {


        string persistentPath = Application.persistentDataPath + "/Picture/";
     

        if (!Directory.Exists(persistentPath))
        {
            Directory.CreateDirectory(persistentPath);
        }

        path = persistentPath + fileName;

        StartCoroutine(DowloadFromServerUrl());
    }
    private IEnumerator DowloadFromServerUrl()
    {
        string jsonString = string.Empty;


        //int width = 
        /*WWW www = new WWW(urlPath);

      
        
        yield return www;

        if (www.error != null)
        {
            throw new Exception("www download : " + www.error);
        }

        jsonString = www.text;*/

        //File.WriteAllText(path, jsonString);

       // DB.Instance.path = path;

        

        yield return null;
    }
    


}
