﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;



public class DBManager : MonoBehaviour {

    private void Start()
    {
        StartCoroutine(CallData());
    }

    private IEnumerator CallData()
    {
        string jsonString = File.ReadAllText(DB.Instance.path);
    //    DB.Instance.gameData = JsonUtility.FromJson<GameData>(jsonString);

        yield return null;
    }



}
