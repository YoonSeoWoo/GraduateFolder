﻿    using System.Collections;
    using System.Collections.Generic;
    using UnityEngine;
    using UnityEngine.EventSystems;
    using UnityEngine.UI;
    using System.Xml.Linq;
    public class ButtonManager : MonoBehaviour {





    int All_Width;
    int All_Height;
       public Texture2D texture_2D_Cutting;

        private float cutting_MousePosition_x = 0;
        private float cutting_MousePosition_y = 0;
        private float cutting_MousePosition_x_two = 0;
        private float cutting_MousePosition_y_two = 0;
   
        private int cutting_MouseCount = 0;
        private bool cutting_Variable = false;
        public Button cutting_Button_Mode;


        [SerializeField] private Vector2 original_Vector;

        private bool editModeVariable = false;
        private bool cameraModeVariable = false;
        public Button editModeButton;
        public Button cameraModeButton;



        public Button x_Axis_Button;
        public Button y_Axis_Button;
        public Button z_Axis_Button;
        private bool x_Axis_Variable = false;
        private bool y_Axis_Variable = false;
        private bool z_Axis_Variable = false;


        public Button x_Position_Button;
        public Button y_Position_Button;
        public Button z_Position_Button;

        public Button position_Plus_Button; //#. Plus인지 
        public Button position_Minus_Button; //#. Minus인지

        private bool plus_Variable = false;
        private bool minus_Variable = false;



        private bool x_Position_Variable = false;
        private bool y_Position_Variable = false;
        private bool z_Position_Variable = false;


        public SpriteRenderer sr;
        [SerializeField] Texture tex;
        [SerializeField] Texture2D tex2D;


        public GameObject spriteRealGroupObject;
    


    


        public int picture_number = 0;
        private bool scrollBackgroundActive = false;

        public GameObject pictureAndSaveObject; //#.pictureAndSaveObject를 표시하기 위한 위치

        public GameObject sprite_Render;

        GameObject scrollBackGround;
        GameObject player;

        public GameObject picture_RawImage; //#.중간에 있는 사진이염

        public GameObject copy_And_Save_Image_Object;




        Button button_SaveToWall;






        public bool automatic_Button_Variable = false;
        Button automatic_Button;



        public SpriteRenderer spriteRender_1;



        private bool scale_Button_Variable = false;




    

        private void Awake()
        {

            sr.gameObject.SetActive(false);


            scrollBackGround = GameObject.FindGameObjectWithTag("GallaryTag");
            player = GameObject.FindGameObjectWithTag("Player");
            button_SaveToWall = GameObject.FindGameObjectWithTag("SaveToWallButton").GetComponent<Button>();
            automatic_Button = GameObject.FindGameObjectWithTag("AutoMaticButtonTag").GetComponent<Button>();

            position_Plus_Button.gameObject.SetActive(false);
            position_Minus_Button.gameObject.SetActive(false);
        }
    
    
        // Use this for initialization
        void Start () {



        All_Height = Screen.height;
        All_Width = Screen.width;
            scrollBackGround.SetActive(false);
            for(int i = 0; i <= 23; i++)
            {
                scrollBackGround.transform.GetChild(0).GetChild(0).GetChild(i).gameObject.SetActive(false);
            }


            //#.Button의 SetActive 랑 enable을 사용을 불가하게 만든다.
            button_SaveToWall.gameObject.SetActive(false);
            button_SaveToWall.enabled = false;

        }

        private void Update()
        {
      
       
                if (cutting_Variable == true)
                {
                    picture_RawImage.SetActive(true);
                    int width = Screen.width;
                    int height = Screen.height;
                    if (Input.GetMouseButtonDown(0))
                    {

                 
                        cutting_MouseCount++;

                        //texture_2D.GetPixel((int)Input.mousePosition.x,(int)Input.mousePosition.y)

                        if (cutting_MouseCount == 2)
                        {
                            cutting_MousePosition_x = Input.mousePosition.x;
                            cutting_MousePosition_y = Input.mousePosition.y;
                        }
                        else if (cutting_MouseCount == 3)
                        {
                            cutting_MousePosition_x_two = Input.mousePosition.x;
                            cutting_MousePosition_y_two = Input.mousePosition.y;
                            cutting_MouseCount = 0;
                        Debug.Log("cuttingMousePosition_x : " + cutting_MousePosition_x + "cuttingMousePosition_y : " + cutting_MousePosition_y);
                        Debug.Log("cuttingMousePosition_x_two : " + cutting_MousePosition_x_two + "cuttingMousePosition_y_two : " + cutting_MousePosition_y_two);

                    StartCoroutine(EndFrameCoRoutine());

                    
                  
                        }




                    }

                }
        
          
        }

        public void GalaryOn_ButtonFunction()
        {
            scrollBackgroundActive = !scrollBackgroundActive;
            scrollBackGround.SetActive(scrollBackgroundActive);
        }


        public void ImageClickAndResult()
        {
            int width = Screen.width;
            int height = Screen.height;
            texture_2D_Cutting = new Texture2D(width, height, TextureFormat.ARGB32, false);
            for (int i = 1; i <= 24; i++)
            {
                string click_Image_Name = "PooImage" + i.ToString();
                if (click_Image_Name == EventSystem.current.currentSelectedGameObject.name)
                {
                    //#.클릭된 아이디가 같을 떄 실행할 내용

                    if (cutting_Variable == true)
                    {
                        width = Screen.width;
                        height = Screen.height;

                        original_Vector = picture_RawImage.gameObject.GetComponentInChildren<RectTransform>().sizeDelta;

                        //#.display라는 RawImage의 크기를 늘렸다. 최대로
                        picture_RawImage.gameObject.GetComponentInChildren<RectTransform>().sizeDelta = new Vector2(width, height);

                        picture_RawImage.gameObject.GetComponent<RawImage>().texture = EventSystem.current.currentSelectedGameObject.GetComponent<RawImage>().texture;

                     

                    }
                    else
                    {
                        GameObject image_Object_Copy = Instantiate(EventSystem.current.currentSelectedGameObject, transform.position, transform.rotation);

                        image_Object_Copy.name = "Wall(CLONE)";

                        copy_And_Save_Image_Object = image_Object_Copy;
                    //#.Image 의 위치가 아직 설정안됨. 마지막에 붙여야함
                    //            Destroy(image_Object_Copy);
                  
                    copy_And_Save_Image_Object.GetComponent<RawImage>().texture = EventSystem.current.currentSelectedGameObject.GetComponent<RawImage>().texture;
                    copy_And_Save_Image_Object.name = "Wall(CLONE)";



            
                    }
                    //#.Image 생성했음

                    scrollBackGround.SetActive(false);
                    break;
                
                }
            }

        
        }

        public void SaveToWallButton_Enable_And_Active_True()
        {
            button_SaveToWall.enabled = true;
            button_SaveToWall.gameObject.SetActive(true);
            picture_RawImage.SetActive(false);
        }
        public void SaveToWall_Image()
        {
            sr.gameObject.SetActive(true);
            // copy_And_Save_Image_Object.transform.parent = pictureAndSaveObject.transform;


            if (copy_And_Save_Image_Object != null)
            {
                tex = copy_And_Save_Image_Object.GetComponent<RawImage>().texture;
                tex2D = (Texture2D)tex;
                sr.sprite = Sprite.Create(tex2D, new Rect(0, 0, tex2D.width, tex2D.height), new Vector2(0.5f, 0.5f), 100);
                if (!automatic_Button_Variable)
                {
                    spriteRender_1 = Instantiate(sr, transform.position, transform.rotation);


                    spriteRender_1.transform.parent = spriteRealGroupObject.transform;


                    Vector3 player_transform = new Vector3(player.transform.position.x, player.transform.position.y, player.transform.position.z);

                    spriteRender_1.transform.position = player_transform;


             



                    //    sprite_Render.GetComponent<SpriteRenderer>().sprite= copy_And_Save_Image_Object.GetComponent<RawImage>().mainTexture;

                }

                Destroy(copy_And_Save_Image_Object);


            }








            sr.gameObject.SetActive(false);

      





        }




        public void EditModeButton()
        {
            editModeVariable = true;
            cameraModeVariable = false;
         //   cameraModeButton.enabled = true;
        //    editModeButton.enabled = false;
            cameraModeButton.interactable = true;
            editModeButton.interactable = false;
            AllAxisVariableFalseFunction_NotClick();
        }

        public void CameraModeButton()
        {

            editModeVariable = false;
            cameraModeVariable = true;
         //   cameraModeButton.enabled = false;
            cameraModeButton.interactable = false;
            editModeButton.interactable = true;
            //      editModeButton.enabled = true;
            AllAxisVariableFalseFunction_NotClick();


        }

   
        public void Z_Axis_Button_Click()
        {
            z_Axis_Variable = true;
            //x_Axis_Button.interactable = true;
            //y_Axis_Button.interactable = true;
            z_Axis_Button.interactable = false;


            editModeVariable = true;
            cameraModeVariable = false;
            //   cameraModeButton.enabled = false;
            cameraModeButton.interactable = true;
            editModeButton.interactable = false;

            PlusAndMinusButtonActive(false);
           // CameraModeButtonAndEditModeButtonFunction_NotClick();
            AllPositionVariableFalseFunction_NotClick();

        }


        public void X_Position_Button_Click()
        {
            x_Position_Variable = true;
            y_Position_Variable = false;
            z_Position_Variable =false;

            x_Position_Button.interactable = false;
            y_Position_Button.interactable = true;
            z_Position_Button.interactable = true;

 
            AllAxisVariableFalseFunction_NotClick();
            CameraModeButtonAndEditModeButtonFunction_NotClick();
            PlusAndMinusButtonActive(x_Position_Variable);

        }
        public void Y_Position_Button_Click()
        {
            x_Position_Variable = false;
            y_Position_Variable = true;
            z_Position_Variable = false;

            x_Position_Button.interactable = true;
            y_Position_Button.interactable = false;
            z_Position_Button.interactable = true;
            PlusAndMinusButtonActive(y_Position_Variable);
            AllAxisVariableFalseFunction_NotClick();
            CameraModeButtonAndEditModeButtonFunction_NotClick();

        }
        public void Z_Position_Button_Click()
        {
            x_Position_Variable = false;
            y_Position_Variable = false;
            z_Position_Variable = true;

            x_Position_Button.interactable = true;
            y_Position_Button.interactable = true;
            z_Position_Button.interactable = false;

            PlusAndMinusButtonActive(z_Position_Variable);
            AllAxisVariableFalseFunction_NotClick();
            CameraModeButtonAndEditModeButtonFunction_NotClick();


        }

        private void CameraModeButtonAndEditModeButtonFunction_NotClick()
        {
            editModeVariable = false;
            cameraModeVariable = false;
            //   cameraModeButton.enabled = false;
            cameraModeButton.interactable = true;
            editModeButton.interactable = true;
        }
    
        private void AllAxisVariableFalseFunction_NotClick()
        {
            x_Axis_Variable = false;
            y_Axis_Variable = false;
            z_Axis_Variable = false;

            //x_Axis_Button.interactable = true;
            //y_Axis_Button.interactable = true;
            z_Axis_Button.interactable = true;
        }

        private void AllPositionVariableFalseFunction_NotClick()
        {
            x_Position_Variable = false;
            y_Position_Variable = false;
            z_Position_Variable = false;

            x_Position_Button.interactable = true;
            y_Position_Button.interactable = true;
            z_Position_Button.interactable = true;
        }


        public void PlusAndMinusButtonActive(bool value)
        {
            position_Plus_Button.gameObject.SetActive(value);
            position_Minus_Button.gameObject.SetActive(value);
        }

        public void PlusButtonClick()
        {

            plus_Variable = true;
            minus_Variable = false;
            position_Plus_Button.gameObject.SetActive(false);
            position_Minus_Button.gameObject.SetActive(false);
        }
        public void MinusButtonClick()
        {
            plus_Variable = false;
            minus_Variable = true;
            position_Plus_Button.gameObject.SetActive(false);
            position_Minus_Button.gameObject.SetActive(false);
        }



    
        public void AutoModeOnButtonClick()
        {
            automatic_Button_Variable = true;
            automatic_Button.interactable = false;

        
        
        }


        public void ScaleModeOnButtonClick()
        {
            scale_Button_Variable = true;
        }

        public bool GetScaleButtonVariable()
        {
            return scale_Button_Variable;
        }

        public void SetScaleButtonVarialbe(bool value)
        {
            scale_Button_Variable = value;
        }


        public void CuttingButtonVariable()
        {
            cutting_Variable = true;
            cutting_Button_Mode.interactable = false;

        }


        public bool GetCuttingVariable()
        {
            return cutting_Variable;
        }

        public void SetCuttingVariable(bool value)
        {
            cutting_Variable = value;
        }

        public bool GetPlusVariable()
        {
            return plus_Variable;
        }

        public bool GetMinusVariable()
        {
            return minus_Variable;
        }

        public void SetPlusVariable(bool value)
        {
            plus_Variable = value;
        }

        public void SetMinusVariable(bool value)
        {
            minus_Variable = value;
        }

        public bool GetXPositionVariable()
        {
            return x_Position_Variable;
        }
        public bool GetYPositionVariable()
        {
            return y_Position_Variable;
        }
        public bool GetZPositionVariable()
        {
            return z_Position_Variable;
        }



        public void SetXPositionVariable(bool value)
        {
            x_Position_Variable = value;
        }
        public void SetYPositionVariable(bool value)
        {
            y_Position_Variable = value;
        }
        public void SetZPositionVariable(bool value)
        {
            z_Position_Variable = value;
        }



        public bool GetXAxisVariable()
        {
            return x_Axis_Variable;
        }
        public bool GetYAxisVariable()
        {
            return y_Axis_Variable;
        }

        public bool GetZAxisVariable()
        {
            return z_Axis_Variable;
        }

        public void SetXAxisVariable(bool value)
        {
            x_Axis_Variable = value;
        }
        public void SetYAxisVariable(bool value)
        {
            y_Axis_Variable = value;
        }

        public void SetZAxisVariable(bool value)
        {
            z_Axis_Variable = value;
        }




        public void SetCameraVariable(bool value)
        {
            cameraModeVariable = value;
        }
        public void SetEditVariable(bool value)
        {
            editModeVariable = value;
        }

        public bool GetCameraVariable()
        {
            return cameraModeVariable;
        }

        public bool GetEditVariable()
        {
            return editModeVariable;
        }

        private IEnumerator EndFrameCoRoutine()
        {


            yield return new WaitForEndOfFrame();
            texture_2D_Cutting.ReadPixels(new Rect(cutting_MousePosition_x, cutting_MousePosition_y, cutting_MousePosition_x_two - cutting_MousePosition_x, cutting_MousePosition_y_two  - cutting_MousePosition_y), 0, 0,false);

            texture_2D_Cutting.Apply();



        Debug.Log(texture_2D_Cutting.width + ": texture2D_cutting width " + texture_2D_Cutting.height + " : texture2D_cutting_height");

        //      Texture2D  texture_2D_temp = new Texture2D(width, height, TextureFormat.ARGB32, false);
        //  texture_2D_Cutting.width = ;
        //  texture_2D_Cutting.height = ;
        Debug.Log(scrollBackGround.transform.GetChild(0).GetChild(0).GetChild(picture_number-1).GetComponent<RawImage>().texture.width + " : Gallary Image width" + scrollBackGround.transform.GetChild(0).GetChild(0).GetChild(picture_number-1).GetComponent<RawImage>().texture.height + "Gallary Image height");

        scrollBackGround.transform.GetChild(0).GetChild(0).GetChild(picture_number).GetComponent<RawImage>().texture = texture_2D_Cutting;
      
            cutting_Variable = false;
            cutting_Button_Mode.interactable = true;
            picture_RawImage.SetActive(false);

        }

    }
