﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DB : GenericSingletonClass<DB> {

	 public string path;
}
