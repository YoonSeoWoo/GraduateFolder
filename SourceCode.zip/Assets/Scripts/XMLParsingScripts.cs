﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Xml;
using System.Xml.Linq;
using System.Linq;

using UnityEngine.UI;







public class XMLParsingScripts : MonoBehaviour {


    public GameObject mouseColliderCapsule;
    private GameObject targetting_Clone;
    RaycastHit hit;
    GameObject target = null;
    Ray ray;

    PositionAndUrlClass positionAndUrlClass = new PositionAndUrlClass(); //#. Json형식으로 닮을 공간;
    string filename = "positionAndUrlData.json";
    string save_path;


    ButtonManager buttonManager;

  




    public GameObject cubeObject; //#. IndoorGML 파싱한 거 담는곳








    public GameObject temp_Cube;
    float[,,] arr_value;

    float[] _x;
    float[] _y;
    float[] _z;
    private void Awake()
    {
        buttonManager = GameObject.FindGameObjectWithTag("ButtonManager").GetComponent<ButtonManager>();
    }
    private void Start()
    {
        const string path = @"C:\Users\yuntake94\Desktop\GraduateSubjectDestop\j90290cd-bfb1-76d6-c5e9-405067e45858 (1).gml";
        save_path = Application.persistentDataPath + "/" + filename;
        Debug.Log(save_path);
        XDocument doc = XDocument.Load(path);
        XElement indoorFeatures = doc.Root;

        XNamespace gml = indoorFeatures.GetNamespaceOfPrefix("gml");
        XNamespace ns = indoorFeatures.GetDefaultNamespace();

        int count = 0;
        int count_one = 0;
        int count_two = 0;
        int count_three = 0;
        arr_value = new float[6, 4, 3];
        _x = new float[4];
        _y = new float[4];
        _z = new float[4];

        var xLinearRing = doc.Descendants(gml + "LinearRing");

        int linearRing_Count = 0;
        foreach(var item in xLinearRing)
        {
            linearRing_Count++;
        }


      

        linearRing_Count /= 6;
        for(int qwe = 0; qwe < linearRing_Count; qwe++)
        {
            //for(int i_i=0;i_i<xLinearRing)
            foreach (var item in xLinearRing)
            {
                var items = item.Elements(gml + "pos").Select(x => new
                {
                    posvalue = (string)x
                });
                foreach (var aaa in items)
                {
                    var eee = aaa.posvalue.Trim();
                    string[] words = eee.Split(' ').ToArray();
                    foreach (var word in words)
                    {
                        arr_value[count_one, count_two, count_three] = float.Parse(word.ToString());

                        count_three++;
                        if (count_three == 3)
                        {
                            count_three = 0;
                            count_two++;
                            if (count_two == 4)
                            {
                                count_two = 0;
                                count_one++;
                            }
                        }
                    }
                    count++;
                    if (count == 4)
                    {
                        count = 0;
                        break;
                    }
                }

            }


            /*
            for()
            GL.Begin(GL.LINES);
            GL.Vertex3(arr_value[count_one, count_two, count_three], arr_value[count_one, count_two, count_three], arr_value[count_one, count_two, count_three]);
            */

            //중심축 , 밑면,높이 길이 각각 받고 이를 Collider에 대입
            //#.첫면 : 아랫면( ,  두번쨰 : 오른쪽면, 세번째: 앞면  네번째 : 왼쪽면   다섯번째 : 뒷면  여섯번쨰 :윗면

            for (int i = 0; i < 6; i++)
            {
                Information info = new Information();
                for (int j = 0; j < 4; j++)
                {
                    if (j == 0)
                    {

                        _x[j] = arr_value[i, j, 0];
                        _y[j] = arr_value[i, j, 1];
                        _z[j] = arr_value[i, j, 2];



                    }
                    else if (j == 1)
                    {
                        _x[j] = arr_value[i, j, 0];
                        _y[j] = arr_value[i, j, 1];
                        _z[j] = arr_value[i, j, 2];
                    }
                    else if (j == 2)
                    {
                        _x[j] = arr_value[i, j, 0];
                        _y[j] = arr_value[i, j, 1];
                        _z[j] = arr_value[i, j, 2];
                    }
                    else if (j == 3)
                    {
                        _x[j] = arr_value[i, j, 0];
                        _y[j] = arr_value[i, j, 1];
                        _z[j] = arr_value[i, j, 2];
                    }
              


                }
                float height = 0;
                float bottom_line = 0;

                //#.center 좌표까지
                float center_x = (_x[0] + _x[2]) / 2;
                float center_y = (_y[0] + _y[2]) / 2;
                float center_z = (_z[0] + _z[2]) / 2;


                if (i == 0)
                {
                    bottom_line = _y[1] - _y[2];
                    height = _x[2] - _x[3];

                }
                else if (i == 1)
                {
                    bottom_line = _x[0] - _x[1];  // x의 길이 0에서 1을뻄
                    height = _z[2] - _z[1];  //y의 길이   z 의 3에서 2를 뻄

                }
                else if (i == 2)
                {
                    //어차피 길이임.
                    bottom_line = _y[0] - _y[1]; //x의 길이 1에서 2를 뺌
                    height = _z[2] - _z[1]; //y의길이  3에서 2를 뻄

                }
                else if (i == 3)
                {
                    bottom_line = _x[0] - _x[1];
                    height = _z[2] - _z[1];

                }
                else if (i == 4)
                {
                    bottom_line = _y[1] - _y[0];
                    height = _z[2] - _z[1];

                }
                else if (i == 5)
                {

                    bottom_line = _y[1] - _y[2]; //y가 2ㅇ서 3을 빼면 됨 안쪽으로 회전해서 붙임
                    height = _x[1] - _x[0];  //x가 2에서 1을 뻄

                }



                GameObject temp_Object = Instantiate(temp_Cube, Vector3.zero, temp_Cube.transform.rotation);
                temp_Object.transform.parent = cubeObject.transform;
                //#.이미 큐브가 z축 0 , BoxClider 사이즈가 0임
                temp_Object.transform.position = new Vector3(center_x, center_y, center_z);
                temp_Object.GetComponent<BoxCollider>().size = new Vector3(bottom_line, height, 0);

                if (i == 0)
                {
                    info.what_side="아랫면,0";
                    info.thi_rotation_x = 0;
                    info.thi_rotation_y = 0;
                    info.thi_rotation_z = 0;
                }
                else if (i == 1)
                {
                    temp_Object.transform.Rotate(new Vector3(-90, 0, 0));
                    info.what_side = "오른쪽면,1";
                    info.thi_rotation_x = -90;
                    info.thi_rotation_y = 0;
                    info.thi_rotation_z = 0;

                }
                else if (i == 2)
                {
                    temp_Object.transform.Rotate(new Vector3(180, -90, -90));
                    info.what_side = "앞면,2";
                    info.thi_rotation_x = 180;
                    info.thi_rotation_y = -90;
                    info.thi_rotation_z = -90;
                }
                else if (i == 3)
                {
                    temp_Object.transform.Rotate(new Vector3(90, 0, 0));
                    info.what_side = "왼쪽면,3";
                    info.thi_rotation_x = 90;
                    info.thi_rotation_y = 0;
                    info.thi_rotation_z = 0;
                }
                else if (i == 4)
                {
                    temp_Object.transform.Rotate(new Vector3(180, 90, 90));

                    info.what_side = "뒷면,4";
                    info.thi_rotation_x = 180;
                    info.thi_rotation_y = 90;
                    info.thi_rotation_z = 90;
                }
                else if (i == 5)
                {
                    info.what_side = "읫면,5";
                    info.thi_rotation_x = 0;
                    info.thi_rotation_y = 0;
                    info.thi_rotation_z = 0;
                }


                //#.중심축, 높이, 밑변 받음 
                //#.높이 밑변은 BoxColider에 쓰일것임
                //#.중심축은 위치
                //#.로테이션은 면마다 다름

                info.pos_x = center_x;
                info.pos_y = center_y;
                info.pos_z = center_z;
                info.height = height;
                info.width = bottom_line;
          

                positionAndUrlClass.informaiton.Add(info);
            



            }


            cubeObject.transform.position = new Vector3(0, 53.1f, 0);

        }
      
    }


    void Update()
    {
       
            ray = Camera.main.ScreenPointToRay(Input.mousePosition); //마우스 포인트 근처 좌표를 만든다. 
            if (true == (Physics.Raycast(ray.origin, ray.direction * 10, out hit)))   //마우스 근처에 오브젝트가 있는지 확인
            {
            //Debug.Log(hit.collider.gameObject.name);
            if (buttonManager.automatic_Button_Variable == true)
            {
                if(hit.collider.gameObject.name== "Cube(Clone)")
                {
                    mouseColliderCapsule.SetActive(true);
                    mouseColliderCapsule.transform.position = new Vector3(
                        hit.collider.transform.position.x, hit.collider.transform.position.y,hit.collider.transform.position.z
                        );
                }
                else
                {
                    mouseColliderCapsule.SetActive(false);
                }
            }
            
                //있으면 오브젝트를 저장한다.

                
            }


        
    }


        






    public void SavePositionAndUrl()
    {

        JsonPlus jsonPlus = new JsonPlus();
        jsonPlus.positionAndUrlClass = positionAndUrlClass;
        string save_PositionAndUrl = JsonUtility.ToJson(jsonPlus, true);
        File.WriteAllText(save_path, save_PositionAndUrl);
    }

    public void ReadPositionAndUrl()
    {
        try
        {
            if (File.Exists(save_path))
            {
                string readPositionAndUrl = File.ReadAllText(save_path);

                JsonPlus jsonPlus = JsonUtility.FromJson<JsonPlus>(readPositionAndUrl);
                positionAndUrlClass = jsonPlus.positionAndUrlClass;

            }
            else
            {
                Debug.Log("Path no exist And file does not");
                positionAndUrlClass = new PositionAndUrlClass();
            }
        }
        catch(System.Exception ex)
        {
            Debug.Log(ex.Message);
        }
       

    }

    

}


