﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Information {

    public float pos_x=0;
    public float pos_y=0;
    public float pos_z=0;
    public float width=0;
    public float height=0;
    public float thi_rotation_x=0;
    public float thi_rotation_y=0;
    public float thi_rotation_z=0;
    public string what_side = "1";
    public string url = "2";
}
